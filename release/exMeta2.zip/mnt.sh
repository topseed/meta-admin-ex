sshfs -o allow_other,defer_permissions root@xxx.xxx.xxx.xxx:/ /root/admin/mntA
