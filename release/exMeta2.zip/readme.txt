
npm i

edit admin.yaml

// path to admin
node index.js .


// note for maintainer - not you: import { Srv, FileOps } from 'meta-admin/lib/ABase'
