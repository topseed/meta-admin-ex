# semi
smaller semantic 

http://github.com/doabit/semantic-ui-sass

you need only 
http://github.com/doabit/semantic-ui-sass/tree/master/app/assets/stylesheets

and work with prepros.io as normal.

edit font, etc.

On page where you need:
http://jsdelivr.com/package/npm/semantic-ui?path=dist%2Fcomponents
